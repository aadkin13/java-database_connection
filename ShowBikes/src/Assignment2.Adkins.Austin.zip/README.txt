Java IoT Assignment 2:

TestMyBike.java:
This is the main java file that runs everything. This is were most of the user input will be prompted and will be directed to the appropriate place.
With in the TestMyBike.java file the InsertRow.java, DeleteRow.java, Database.java, and the ShowBike.java file will be intialized and called.

InsertRow.java:
This is a simple couple lines of code that takes in user inputs and takes the data and inserts it into the database.

DeleteRow.java:
In the DeleteRow.java file, I wanted it to delete exactly one row. So it prompts the user to input the data of the row that they want to delete and 
it will delete only that row.


ShowBikes.java:
This is the start for the search function. In the ShowBike.java file it prompts the user to give the columns and the data they want to display. If
the user would like to just see all the data in a specific column then the user will input "info" and all the data will display.

SearchTable.java:
In the SearchTable.java, it takes all the information taken from the ShowBikes.java and organizes the information to be displayed. 