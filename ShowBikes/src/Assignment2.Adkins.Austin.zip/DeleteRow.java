import java.sql.*;

public class DeleteRow {
	void deleteRow(Connection conn, String dbName, String tableName, String tableKey, String tableValue) throws SQLException{
		Statement stmt = null;
		stmt = conn.createStatement();
		String sql = "DELETE FROM "+dbName+"."+tableName+" WHERE "+tableKey+"= '"+tableValue+"';";
		stmt.executeUpdate(sql);
	}

}
