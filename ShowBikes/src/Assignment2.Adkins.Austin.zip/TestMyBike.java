import java.sql.*;
import java.util.*;

public class TestMyBike {
	public static void main(String[] args) throws Exception{
		
		
		String url ="jdbc:mysql://localhost:3306";
		String username="root";
		String password ="buckey3s";
		String dbName="bicycles";
		String tableName="attributes";
		
		String[] type= {"mountain_bike","race_bike","street_bike"};
		String[] color= {"steel","red","blue","black"};
		String[] constMat= {"carbon","steel","aluminium"};
		String delimiter1="\",\"";
		String delimiter2="\"";
		
		Database db = new Database();
		InsertRow ir = new InsertRow();
		DeleteRow dr = new DeleteRow();
		SearchTable st = new SearchTable();
		ShowBikes sb = new ShowBikes();
		Scanner input = new Scanner(System.in);
		
		Statement stmnt = null;
		ResultSet resultSet = null;
		
		try {
			Connection conn = db.serverConnect(url, username, password);
			stmnt = conn.createStatement();
			resultSet = conn.getMetaData().getCatalogs();
			while(resultSet.next()) {
				String dataBaseName = resultSet.getString(1);
				if(dataBaseName.equals(dbName)) {
					break;
				}else {
					db.createDatabase(conn, dbName);
					db.createTable(conn, dbName, tableName,"type varchar(45)","gearNum int","wheelBase int", "height int","color varchar(45)","constMat varchar(45)" );
					for(int i = 0; i<type.length;i++) {
						for(int j =4; j<=10;j++) {
							for(int k=36; k<=60;k+=6) {
								for(int l =1;l<=4;l++) {
									for(int m =0;m<color.length;m++) {
										for(int n=0;n<constMat.length;n++) {
											String tableValue=delimiter2+type[i]+delimiter1+String.valueOf(j)+delimiter1+String.valueOf(k)+delimiter1+String.valueOf(l)+
													delimiter1+color[m]+delimiter1+constMat[n]+delimiter2;
											ir.insertRow(conn, dbName, tableName, "type,gearNum,wheelBase,height,color,constMat",tableValue);
										}
									}
								}
							}
						}
					}
					break;
				}
			}
			System.out.println("Please choose an option (enter -1 to end):\n1. Insert Row\n2. Delete Row\n3. Search\n4. Display Database");
			int choose = input.nextInt();
			while(choose != -1) {
				switch(choose) {
				case 1:
					System.out.println("1. type\n2. gearNum\n3. wheelBase\n4. height\n5. color\n6. constMat");
					choose = input.nextInt();
					switch(choose) {
					case 1:
						System.out.println("enter the value that will be entered in type");
						String tableValue = input.next();
						ir.insertRow(conn, dbName, tableName, "type", tableValue);
						break;
					case 2:
						System.out.println("enter the value that will be entered in gearNum");
						tableValue = input.next();
						ir.insertRow(conn, dbName, tableName, "gearNum", tableValue);
						break;
					case 3:
						System.out.println("enter the value that will be entered in wheelBase");
						tableValue = input.next();
						ir.insertRow(conn, dbName, tableName, "wheelBase", tableValue);
						break;
					case 4:
						System.out.println("enter the value that will be entered in height");
						tableValue = input.next();
						ir.insertRow(conn, dbName, tableName, "height", tableValue);
						break;
					case 5:
						System.out.println("enter the value that will be entered in color");
						tableValue = input.next();
						ir.insertRow(conn, dbName, tableName, "color", tableValue);
						break;
					case 6:
						System.out.println("enter the value that will be entered in constMat");
						tableValue = input.next();
						ir.insertRow(conn, dbName, tableName, "constMat", tableValue);
						break;
					}
					break;
				case 2:
					System.out.println("1. type\n2. gearNum\n3. wheelBase\n4. height\n5. color\n6. constMat");
					choose = input.nextInt();
					switch(choose) {
					case 1:
						System.out.println("enter the value that will be deleted in type");
						String tableValue = input.next();
						dr.deleteRow(conn, dbName, tableName, "type", tableValue);
						break;
					case 2:
						System.out.println("enter the value that will be deleted in gearNum");
						tableValue = input.next();
						dr.deleteRow(conn, dbName, tableName, "gearNum", tableValue);
						break;
					case 3:
						System.out.println("enter the value that will be deleted in wheelBase");
						tableValue = input.next();
						dr.deleteRow(conn, dbName, tableName, "wheelBase", tableValue);
						break;
					case 4:
						System.out.println("enter the value that will be deleted in height");
						tableValue = input.next();
						dr.deleteRow(conn, dbName, tableName, "height", tableValue);
						break;
					case 5:
						System.out.println("enter the value that will be deleted in color");
						tableValue = input.next();
						dr.deleteRow(conn, dbName, tableName, "color", tableValue);
						break;
					case 6:
						System.out.println("enter the value that will be deleted in constMat");
						tableValue = input.next();
						dr.deleteRow(conn, dbName, tableName, "constMat", tableValue);
						break;
					}
					break;
				case 3:
					sb.searchDB(conn, dbName, tableName);
					break;
				case 4:
					String sql = "select * from "+dbName+"."+tableName+";";
					resultSet = stmnt.executeQuery(sql);
					while(resultSet.next()) {
						System.out.println(resultSet.getString(1)+" "+ resultSet.getString(2)+" "+resultSet.getString(3)+" "+resultSet.getString(4)+" "+resultSet.getString(5)+" "+resultSet.getString(6));
					}
					break;
				}
				System.out.println("Please choose an option (enter -1 to end):\n1. Insert Row\n2. Delete Row\n3. Search\n4. Display Database");
				choose = input.nextInt();
			}
			
			db.serverDisconnect(conn);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
